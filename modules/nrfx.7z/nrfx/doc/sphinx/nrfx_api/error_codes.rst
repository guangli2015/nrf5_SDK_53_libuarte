Global Error Codes
==================

.. doxygengroup:: nrfx_error_codes
   :project: nrfx
   :members: