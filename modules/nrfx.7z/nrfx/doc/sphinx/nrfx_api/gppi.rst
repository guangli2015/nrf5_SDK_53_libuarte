Generic PPI Layer
=================

.. doxygengroup:: nrfx_gppi
   :project: nrfx
   :members: