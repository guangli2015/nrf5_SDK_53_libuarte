Core-dependent functionality
============================

.. doxygengroup:: nrfx_coredep
   :project: nrfx
   :members: