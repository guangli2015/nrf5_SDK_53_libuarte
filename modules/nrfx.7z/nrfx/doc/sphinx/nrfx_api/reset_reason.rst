Generic Reset Reason layer
==========================

.. doxygengroup:: nrfx_reset_reason
   :project: nrfx
   :members: