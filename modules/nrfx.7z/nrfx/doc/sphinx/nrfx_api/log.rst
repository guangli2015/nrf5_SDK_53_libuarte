nrfx_log.h
==========

.. doxygengroup:: nrfx_log
   :project: nrfx
   :members: