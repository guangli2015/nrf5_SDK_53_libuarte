Common module
=============

.. doxygengroup:: nrfx_common
   :project: nrfx
   :members: