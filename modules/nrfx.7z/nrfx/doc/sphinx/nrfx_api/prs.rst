Peripheral Resource Sharing (PRS)
=================================

.. doxygengroup:: nrfx_prs
   :project: nrfx
   :members: