API Reference
=============

.. toctree::

    drivers/index
    nrfx_api/index