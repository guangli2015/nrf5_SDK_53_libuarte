OSCILLATORS HAL
===============

.. doxygengroup:: nrf_oscillators_hal
   :project: nrfx
   :members:
