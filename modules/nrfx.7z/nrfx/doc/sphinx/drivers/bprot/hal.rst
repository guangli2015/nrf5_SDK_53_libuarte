BPROT HAL
=========

.. doxygengroup:: nrf_bprot_hal
   :project: nrfx
   :members:
