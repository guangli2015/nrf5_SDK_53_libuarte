COMP driver
===========

.. doxygengroup:: nrfx_comp
   :project: nrfx
   :members:
