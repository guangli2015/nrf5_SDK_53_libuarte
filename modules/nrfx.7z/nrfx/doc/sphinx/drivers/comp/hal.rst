COMP HAL
========

.. doxygengroup:: nrf_comp_hal
   :project: nrfx
   :members:
