PPI driver
==========

.. doxygengroup:: nrfx_ppi
   :project: nrfx
   :members:
