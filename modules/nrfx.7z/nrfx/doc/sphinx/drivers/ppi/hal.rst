PPI HAL
=======

.. doxygengroup:: nrf_ppi_hal
   :project: nrfx
   :members:
