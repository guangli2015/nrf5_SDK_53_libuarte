PPI
===

.. doxygengroup:: nrf_ppi

.. toctree::
   :glob:

   ../../nrfx_api/gppi.rst
   *
