IPC driver
==========

.. doxygengroup:: nrfx_ipc
   :project: nrfx
   :members:
