IPC
===

.. doxygengroup:: nrf_ipc

.. toctree::
   :glob:

   *