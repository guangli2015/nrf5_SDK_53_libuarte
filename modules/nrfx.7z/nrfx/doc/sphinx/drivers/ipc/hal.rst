IPC HAL
=======

.. doxygengroup:: nrf_ipc_hal
   :project: nrfx
   :members:
