ACL HAL
=======

.. doxygengroup:: nrf_acl_hal
   :project: nrfx
   :members:
