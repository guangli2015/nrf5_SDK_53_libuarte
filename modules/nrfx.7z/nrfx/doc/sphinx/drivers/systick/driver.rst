SYSTICK driver
==============

.. doxygengroup:: nrfx_systick
   :project: nrfx
   :members:
