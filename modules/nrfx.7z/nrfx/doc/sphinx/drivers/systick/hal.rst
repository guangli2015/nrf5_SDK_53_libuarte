SYSTICK HAL
===========

.. doxygengroup:: nrf_systick_hal
   :project: nrfx
   :members:
