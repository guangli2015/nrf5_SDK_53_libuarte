GPIO HAL
========

.. doxygengroup:: nrf_gpio_hal
   :project: nrfx
   :members:
