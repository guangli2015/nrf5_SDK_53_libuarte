USBD driver
===========

.. doxygengroup:: nrfx_usbd
   :project: nrfx
   :members:
