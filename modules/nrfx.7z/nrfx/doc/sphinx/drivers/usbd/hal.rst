USBD HAL
========

.. doxygengroup:: nrf_usbd_hal
   :project: nrfx
   :members:
