UARTE driver
============

.. doxygengroup:: nrfx_uarte
   :project: nrfx
   :members:
