UARTE HAL
=========

.. doxygengroup:: nrf_uarte_hal
   :project: nrfx
   :members:
