UARTE
=====

.. doxygengroup:: nrf_uarte

.. toctree::
   :glob:

   *