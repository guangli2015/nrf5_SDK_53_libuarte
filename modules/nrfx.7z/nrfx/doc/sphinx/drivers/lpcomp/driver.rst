LPCOMP driver
=============

.. doxygengroup:: nrfx_lpcomp
   :project: nrfx
   :members:
