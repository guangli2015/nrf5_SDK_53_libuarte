LPCOMP HAL
==========

.. doxygengroup:: nrf_lpcomp_hal
   :project: nrfx
   :members:
