RESET HAL
=========

.. doxygengroup:: nrf_reset_hal
   :project: nrfx
   :members:
