DPPI
====

.. doxygengroup:: nrf_dppi

.. toctree::
   :glob:

   ../../nrfx_api/gppi.rst
   *
