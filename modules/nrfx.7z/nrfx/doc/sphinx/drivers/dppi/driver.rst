DPPI driver
===========

.. doxygengroup:: nrfx_dppi
   :project: nrfx
   :members:
