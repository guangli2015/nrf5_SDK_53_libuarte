DPPI HAL
========

.. doxygengroup:: nrf_dppi_hal
   :project: nrfx
   :members:
