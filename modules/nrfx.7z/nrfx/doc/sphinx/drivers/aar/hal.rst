AAR HAL
=======

.. doxygengroup:: nrf_aar_hal
   :project: nrfx
   :members:
