NFCT driver
===========

.. doxygengroup:: nrfx_nfct
   :project: nrfx
   :members:
