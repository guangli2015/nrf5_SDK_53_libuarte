NFCT HAL
========

.. doxygengroup:: nrf_nfct_hal
   :project: nrfx
   :members:
