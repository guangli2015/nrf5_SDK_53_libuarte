QSPI HAL
========

.. doxygengroup:: nrf_qspi_hal
   :project: nrfx
   :members:
