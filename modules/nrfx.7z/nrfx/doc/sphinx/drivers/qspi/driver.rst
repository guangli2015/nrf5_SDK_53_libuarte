QSPI driver
===========

.. doxygengroup:: nrfx_qspi
   :project: nrfx
   :members:
