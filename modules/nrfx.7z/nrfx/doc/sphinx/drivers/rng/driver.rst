RNG driver
==========

.. doxygengroup:: nrfx_rng
   :project: nrfx
   :members:
