RNG HAL
=======

.. doxygengroup:: nrf_rng_hal
   :project: nrfx
   :members:
