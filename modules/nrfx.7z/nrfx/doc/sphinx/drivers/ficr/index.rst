FICR
====

.. doxygengroup:: nrf_ficr

.. toctree::
   :glob:

   *