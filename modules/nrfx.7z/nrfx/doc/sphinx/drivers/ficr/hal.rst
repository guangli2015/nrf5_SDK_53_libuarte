FICR HAL
========

.. doxygengroup:: nrf_ficr_hal
   :project: nrfx
   :members:
