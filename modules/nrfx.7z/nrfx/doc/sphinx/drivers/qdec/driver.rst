QDEC driver
===========

.. doxygengroup:: nrfx_qdec
   :project: nrfx
   :members:
