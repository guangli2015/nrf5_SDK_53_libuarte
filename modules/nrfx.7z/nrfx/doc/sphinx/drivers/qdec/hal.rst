QDEC HAL
========

.. doxygengroup:: nrf_qdec_hal
   :project: nrfx
   :members:
