QDEC
====

.. doxygengroup:: nrf_qdec

.. toctree::
   :glob:

   *