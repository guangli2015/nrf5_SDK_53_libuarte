ADC
===

.. doxygengroup:: nrf_adc

.. toctree::
   :glob:

   *