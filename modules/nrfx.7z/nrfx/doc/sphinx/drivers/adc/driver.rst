ADC driver
==========

.. doxygengroup:: nrfx_adc
   :project: nrfx
   :members:
