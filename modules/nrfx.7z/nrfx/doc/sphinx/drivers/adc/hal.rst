ADC HAL
=======

.. doxygengroup:: nrf_adc_hal
   :project: nrfx
   :members:
