MWU HAL
=======

.. doxygengroup:: nrf_mwu_hal
   :project: nrfx
   :members:
