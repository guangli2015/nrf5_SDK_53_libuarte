VREQCTRL HAL
============

.. doxygengroup:: nrf_vreqctrl_hal
   :project: nrfx
   :members:
