CLOCK HAL
=========

.. doxygengroup:: nrf_clock_hal
   :project: nrfx
   :members:
