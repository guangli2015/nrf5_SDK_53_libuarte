CLOCK
=====

.. doxygengroup:: nrf_clock

.. toctree::
   :glob:

   *
   ../oscillators/hal.rst
