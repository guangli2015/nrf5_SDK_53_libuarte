CLOCK driver
============

.. doxygengroup:: nrfx_clock
   :project: nrfx
   :members:
