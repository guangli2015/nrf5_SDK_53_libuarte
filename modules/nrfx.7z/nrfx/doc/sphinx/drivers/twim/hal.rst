TWIM HAL
========

.. doxygengroup:: nrf_twim_hal
   :project: nrfx
   :members:
