TWIM driver
===========

.. doxygengroup:: nrfx_twim
   :project: nrfx
   :members:
