TIMER
=====

.. doxygengroup:: nrf_timer

.. toctree::
   :glob:

   *