TIMER HAL
=========

.. doxygengroup:: nrf_timer_hal
   :project: nrfx
   :members:
