TIMER driver
============

.. doxygengroup:: nrfx_timer
   :project: nrfx
   :members:
