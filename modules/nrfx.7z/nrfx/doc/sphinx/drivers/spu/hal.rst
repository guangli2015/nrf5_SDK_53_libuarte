SPU HAL
=======

.. doxygengroup:: nrf_spu_hal
   :project: nrfx
   :members:
