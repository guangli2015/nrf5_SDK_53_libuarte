SPIM
====

.. doxygengroup:: nrf_spim

.. toctree::
   :glob:

   *