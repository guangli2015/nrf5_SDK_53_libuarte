SPIM HAL
========

.. doxygengroup:: nrf_spim_hal
   :project: nrfx
   :members:
