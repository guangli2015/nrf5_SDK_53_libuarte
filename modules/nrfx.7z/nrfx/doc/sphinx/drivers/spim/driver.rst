SPIM driver
===========

.. doxygengroup:: nrfx_spim
   :project: nrfx
   :members:
