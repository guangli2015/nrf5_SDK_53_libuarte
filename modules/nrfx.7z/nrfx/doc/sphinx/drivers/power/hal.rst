POWER HAL
=========

.. doxygengroup:: nrf_power_hal
   :project: nrfx
   :members:
