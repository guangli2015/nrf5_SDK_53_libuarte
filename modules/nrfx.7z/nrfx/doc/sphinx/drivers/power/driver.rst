POWER driver
============

.. doxygengroup:: nrfx_power
   :project: nrfx
   :members:
