POWER
=====

.. doxygengroup:: nrf_power

.. toctree::
   :glob:

   ../../nrfx_api/reset_reason.rst
   *
   ../reset/hal.rst
   ../usbreg/driver.rst
   ../usbreg/hal.rst
   ../regulators/hal.rst
   ../vreqctrl/hal.rst
