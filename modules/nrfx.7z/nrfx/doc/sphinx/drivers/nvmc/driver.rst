NVMC driver
===========

.. doxygengroup:: nrfx_nvmc
   :project: nrfx
   :members:
