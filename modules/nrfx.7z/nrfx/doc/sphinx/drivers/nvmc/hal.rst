NVMC HAL
========

.. doxygengroup:: nrf_nvmc_hal
   :project: nrfx
   :members:
