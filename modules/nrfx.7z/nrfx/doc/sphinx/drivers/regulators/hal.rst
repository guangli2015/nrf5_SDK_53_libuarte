REGULATORS HAL
==============

.. doxygengroup:: nrf_regulators_hal
   :project: nrfx
   :members:
