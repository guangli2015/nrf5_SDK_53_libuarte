PDM HAL
=======

.. doxygengroup:: nrf_pdm_hal
   :project: nrfx
   :members:
