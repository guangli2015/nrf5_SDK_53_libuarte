PDM driver
==========

.. doxygengroup:: nrfx_pdm
   :project: nrfx
   :members:
