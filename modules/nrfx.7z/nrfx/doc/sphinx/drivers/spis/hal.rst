SPIS HAL
========

.. doxygengroup:: nrf_spis_hal
   :project: nrfx
   :members:
