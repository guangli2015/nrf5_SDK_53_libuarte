SPIS driver
===========

.. doxygengroup:: nrfx_spis
   :project: nrfx
   :members:
