MUTEX HAL
=========

.. doxygengroup:: nrf_mutex_hal
   :project: nrfx
   :members:
