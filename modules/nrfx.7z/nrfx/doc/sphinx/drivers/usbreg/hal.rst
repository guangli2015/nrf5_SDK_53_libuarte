USBREG HAL
==========

.. doxygengroup:: nrf_usbreg_hal
   :project: nrfx
   :members:
