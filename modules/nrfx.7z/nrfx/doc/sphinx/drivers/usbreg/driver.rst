USBREG driver
=============

.. doxygengroup:: nrfx_usbreg
   :project: nrfx
   :members:
