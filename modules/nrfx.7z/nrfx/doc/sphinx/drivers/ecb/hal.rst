ECB HAL
=======

.. doxygengroup:: nrf_ecb_hal
   :project: nrfx
   :members:
