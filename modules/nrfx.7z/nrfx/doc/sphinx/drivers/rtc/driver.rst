RTC driver
==========

.. doxygengroup:: nrfx_rtc
   :project: nrfx
   :members:
