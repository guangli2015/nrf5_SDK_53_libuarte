RTC
===

.. doxygengroup:: nrf_rtc

.. toctree::
   :glob:

   *