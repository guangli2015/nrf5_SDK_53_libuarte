RTC HAL
=======

.. doxygengroup:: nrf_rtc_hal
   :project: nrfx
   :members:
