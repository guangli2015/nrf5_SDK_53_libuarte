SAADC HAL
=========

.. doxygengroup:: nrf_saadc_hal
   :project: nrfx
   :members:
