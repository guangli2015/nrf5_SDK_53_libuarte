SAADC driver
============

.. doxygengroup:: nrfx_saadc
   :project: nrfx
   :members:
