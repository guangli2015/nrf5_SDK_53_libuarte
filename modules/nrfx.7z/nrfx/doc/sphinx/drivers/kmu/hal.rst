KMU HAL
=======

.. doxygengroup:: nrf_kmu_hal
   :project: nrfx
   :members:
