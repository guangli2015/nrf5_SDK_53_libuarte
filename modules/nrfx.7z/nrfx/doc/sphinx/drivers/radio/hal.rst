RADIO HAL
=========

.. doxygengroup:: nrf_radio_hal
   :project: nrfx
   :members:
