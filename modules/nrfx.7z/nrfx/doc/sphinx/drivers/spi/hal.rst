SPI HAL
=======

.. doxygengroup:: nrf_spi_hal
   :project: nrfx
   :members:
