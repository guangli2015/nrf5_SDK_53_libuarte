SPI driver
==========

.. doxygengroup:: nrfx_spi
   :project: nrfx
   :members:
