UART HAL
========

.. doxygengroup:: nrf_uart_hal
   :project: nrfx
   :members:
