UART driver
===========

.. doxygengroup:: nrfx_uart
   :project: nrfx
   :members:
