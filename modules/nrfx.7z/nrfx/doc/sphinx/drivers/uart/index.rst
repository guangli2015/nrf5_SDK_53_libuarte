UART
====

.. doxygengroup:: nrf_uart

.. toctree::
   :glob:

   *