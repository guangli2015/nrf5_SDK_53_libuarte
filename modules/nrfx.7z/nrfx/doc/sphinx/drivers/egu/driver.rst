EGU driver
==========

.. doxygengroup:: nrfx_egu
   :project: nrfx
   :members:
