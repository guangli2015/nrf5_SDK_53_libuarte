EGU HAL
=======

.. doxygengroup:: nrf_egu_hal
   :project: nrfx
   :members:
