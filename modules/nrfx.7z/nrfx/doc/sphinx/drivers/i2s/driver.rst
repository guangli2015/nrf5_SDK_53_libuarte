I2S driver
==========

.. doxygengroup:: nrfx_i2s
   :project: nrfx
   :members:
