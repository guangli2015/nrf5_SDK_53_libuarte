I2S HAL
=======

.. doxygengroup:: nrf_i2s_hal
   :project: nrfx
   :members:
