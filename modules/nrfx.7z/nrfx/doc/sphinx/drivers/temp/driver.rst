TEMP driver
===========

.. doxygengroup:: nrfx_temp
   :project: nrfx
   :members:
