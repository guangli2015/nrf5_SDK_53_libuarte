TEMP HAL
========

.. doxygengroup:: nrf_temp_hal
   :project: nrfx
   :members:
