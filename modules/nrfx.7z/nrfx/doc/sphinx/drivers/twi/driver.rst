TWI driver
==========

.. doxygengroup:: nrfx_twi
   :project: nrfx
   :members:
