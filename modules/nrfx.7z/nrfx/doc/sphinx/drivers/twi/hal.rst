TWI HAL
=======

.. doxygengroup:: nrf_twi_hal
   :project: nrfx
   :members:
