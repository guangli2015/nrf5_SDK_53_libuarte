FPU HAL
=======

.. doxygengroup:: nrf_fpu_hal
   :project: nrfx
   :members:
