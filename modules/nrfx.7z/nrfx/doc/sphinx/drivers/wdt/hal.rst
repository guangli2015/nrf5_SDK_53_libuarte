WDT HAL
=======

.. doxygengroup:: nrf_wdt_hal
   :project: nrfx
   :members:
