WDT driver
==========

.. doxygengroup:: nrfx_wdt
   :project: nrfx
   :members:
