DCNF HAL
========

.. doxygengroup:: nrf_dcnf_hal
   :project: nrfx
   :members:
