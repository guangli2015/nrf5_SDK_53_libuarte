PWM driver
==========

.. doxygengroup:: nrfx_pwm
   :project: nrfx
   :members:
