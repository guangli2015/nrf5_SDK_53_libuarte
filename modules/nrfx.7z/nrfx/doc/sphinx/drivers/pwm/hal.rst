PWM HAL
=======

.. doxygengroup:: nrf_pwm_hal
   :project: nrfx
   :members:
