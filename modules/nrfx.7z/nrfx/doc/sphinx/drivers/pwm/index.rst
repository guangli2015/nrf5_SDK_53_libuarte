PWM
===

.. doxygengroup:: nrf_pwm

.. toctree::
   :glob:

   *