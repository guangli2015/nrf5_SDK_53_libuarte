VMC HAL
=======

.. doxygengroup:: nrf_vmc_hal
   :project: nrfx
   :members:
