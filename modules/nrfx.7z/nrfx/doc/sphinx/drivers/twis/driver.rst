TWIS driver
===========

.. doxygengroup:: nrfx_twis
   :project: nrfx
   :members:
