TWIS HAL
========

.. doxygengroup:: nrf_twis_hal
   :project: nrfx
   :members:
