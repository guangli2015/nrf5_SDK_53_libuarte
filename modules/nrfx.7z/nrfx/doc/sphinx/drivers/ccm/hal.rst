CCM HAL
=======

.. doxygengroup:: nrf_ccm_hal
   :project: nrfx
   :members:
