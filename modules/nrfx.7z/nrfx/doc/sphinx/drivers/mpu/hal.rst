MPU HAL
=======

.. doxygengroup:: nrf_mpu_hal
   :project: nrfx
   :members:
