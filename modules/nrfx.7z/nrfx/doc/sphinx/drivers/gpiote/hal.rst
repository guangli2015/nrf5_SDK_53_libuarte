GPIOTE HAL
==========

.. doxygengroup:: nrf_gpiote_hal
   :project: nrfx
   :members:
