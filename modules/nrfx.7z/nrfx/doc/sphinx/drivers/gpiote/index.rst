GPIOTE
======

.. doxygengroup:: nrf_gpiote

.. toctree::
   :glob:

   *