GPIOTE driver
=============

.. doxygengroup:: nrfx_gpiote
   :project: nrfx
   :members:
